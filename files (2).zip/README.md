# Musicord v0.2 (untested): free hosting edition
Stack: Render (free web service) + Supabase (free Postgres database + free file storage).
Render's own free Postgres is deleted after 30 days, so we do not use it.

## Deploy, step by step
1. GitHub: create an account, press New repository (name: musicord), then "uploading an existing file" and drag in everything from this folder (including the public folder). Do NOT upload any file with real passwords.
2. Supabase (supabase.com): New project. Save the database password you choose.
   - Storage > New bucket > name `musicord` > turn on "Public bucket".
   - Project Settings > API: copy the Project URL and the secret (service_role) key.
   - Click Connect at the top > "Session pooler": copy the connection string and put your password in place of [YOUR-PASSWORD].
3. Render (render.com): New > Web Service > pick your GitHub repo. Build command `npm install`, start command `npm start`, instance type Free.
   Add environment variables (see .env.example): DATABASE_URL, SUPABASE_URL, SUPABASE_SERVICE_KEY, SUPABASE_BUCKET=musicord, SECURE_COOKIES=1.
4. Wait for "Musicord ready" in the logs, then open your onrender.com address.

## Songs expire
Every track (uploads and links) disappears 10 hours after it is posted. A cleanup job runs every 10 minutes and when the site wakes up: it deletes expired tracks and their audio and cover files from Supabase, plus abandoned uploads and replaced profile pictures older than an hour. Expired tracks are hidden immediately even if cleanup has not run yet. To change the time, edit `interval '10 hours'` in schema.sql (only affects new tracks) and TTL in public/index.html.

## Free-tier facts to expect
- Render free sites sleep after 15 minutes idle; the first visit afterward takes about a minute. Voice calls end when it sleeps.
- Supabase free projects pause after a week of inactivity; press Restore in the Supabase dashboard if that happens.
- Supabase free storage is 1 GB; the database is 500 MB.
- Keep the secret key private: it lives only in Render's environment settings, never in the code.

## Not built yet
SoundCloud/Spotify account login, DMs and friends, screen sharing, TURN server, email verification and password reset, copyright report/takedown tools.
