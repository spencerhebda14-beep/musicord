const express=require('express'),http=require('http'),crypto=require('crypto'),fs=require('fs'),path=require('path');
const{Pool}=require('pg'),bcrypt=require('bcryptjs'),{WebSocketServer}=require('ws');
const{DATABASE_URL,SUPABASE_URL='',SUPABASE_SERVICE_KEY='',SUPABASE_BUCKET='musicord'}=process.env;
if(!DATABASE_URL||!SUPABASE_URL||!SUPABASE_SERVICE_KEY){console.error('Missing DATABASE_URL, SUPABASE_URL or SUPABASE_SERVICE_KEY. See README.');process.exit(1)}
const SB=SUPABASE_URL.replace(/\/$/,''),pool=new Pool({connectionString:DATABASE_URL,ssl:{rejectUnauthorized:false},max:5});pool.on('error',e=>console.error('db',e.message));
const all=async(t,p)=>(await pool.query(t,p)).rows,one=async(t,p)=>(await all(t,p))[0],num=v=>Number.isInteger(+v)?+v:0;
const app=express(),server=http.createServer(app);app.disable('x-powered-by');app.set('trust proxy',1);
const wrap=f=>(q,r,n)=>f(q,r,n).catch(e=>{console.error(e.message);if(!r.headersSent)r.status(500).json({error:'Something went wrong on our side'})});
app.use((q,r,n)=>{r.set({'X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Referrer-Policy':'strict-origin-when-cross-origin',
 'Content-Security-Policy':`default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: ${SB}; media-src 'self' blob: ${SB}; connect-src 'self' ws: wss:; frame-src https://w.soundcloud.com https://open.spotify.com`});n()});
app.use(express.json({limit:'20kb'}));
// CSRF: SameSite=Strict cookie plus a custom header that other websites cannot send without a CORS preflight
app.use('/api',(q,r,n)=>{if(q.method!=='GET'&&q.headers['x-requested-with']!=='musicord')return r.status(403).json({error:'Bad request'});n()});
const hits=new Map();const limited=(k,max,ms)=>{const n=Date.now(),a=(hits.get(k)||[]).filter(t=>n-t<ms);a.push(n);hits.set(k,a);return a.length>max};
const sha=s=>crypto.createHash('sha256').update(s).digest('hex'),cookie=h=>Object.fromEntries((h||'').split(';').map(c=>c.trim().split('=')).filter(a=>a[0]));
const userFrom=async q=>{const t=cookie(q.headers.cookie).sid;return t?one('SELECT u.id,u.username FROM sessions s JOIN users u ON u.id=s.user_id WHERE token_hash=$1 AND expires_at>$2',[sha(t),Date.now()]):null};
const auth=wrap(async(q,r,n)=>{const u=await userFrom(q);if(!u)return r.status(401).json({error:'Please sign in'});q.user=u;n()});
const role=async(s,u)=>(await one('SELECT role FROM members WHERE server_id=$1 AND user_id=$2',[num(s),num(u)]))?.role,chan=id=>one('SELECT * FROM channels WHERE id=$1',[num(id)]);
const canManage=r=>r==='owner'||r==='admin',canMod=r=>canManage(r)||r==='moderator';
const PUB='u.id uid,u.username,u.display,u.avatar,u.accent';
(async()=>{await pool.query(fs.readFileSync(path.join(__dirname,'schema.sql'),'utf8'));server.listen(process.env.PORT||3000,()=>console.log('Musicord ready'));sweep();setInterval(sweep,10*60e3)})().catch(e=>{console.error('Database setup failed:',e.message);process.exit(1)});
/* ---- accounts ---- */
app.post('/api/register',wrap(async(q,r)=>{if(limited('reg'+q.ip,10,3600e3))return r.status(429).json({error:'Too many attempts'});
 const{username,email,password,dob}=q.body||{};
 if(!/^[A-Za-z0-9_]{3,24}$/.test(username||''))return r.status(400).json({error:'Username: 3-24 letters, numbers or underscores'});
 if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email||''))return r.status(400).json({error:'Enter a valid email'});
 if(typeof password!=='string'||password.length<10||password.length>200)return r.status(400).json({error:'Password needs 10+ characters'});
 const d=new Date(dob);if(isNaN(d))return r.status(400).json({error:'Enter your date of birth'});
 const n=new Date();let age=n.getFullYear()-d.getFullYear();if(n<new Date(n.getFullYear(),d.getMonth(),d.getDate()))age--;
 if(age<13)return r.status(403).json({error:'You must be 13 or older'});
 try{await pool.query('INSERT INTO users(username,email,pass_hash,birth_year,display) VALUES($1,$2,$3,$4,$1)',[username,email,await bcrypt.hash(password,12),d.getFullYear()]);r.json({ok:true})}catch(e){if(e.code==='23505')return r.status(409).json({error:'Username or email unavailable'});throw e}}));
app.post('/api/login',wrap(async(q,r)=>{if(limited('login'+q.ip,10,900e3))return r.status(429).json({error:'Too many attempts, try later'});
 const{email,password}=q.body||{},u=await one('SELECT * FROM users WHERE LOWER(email)=LOWER($1)',[String(email||'')]);
 const ok=await bcrypt.compare(String(password||''),u?u.pass_hash:'$2a$12$invalidinvalidinvalidinvalidinvalidinvalidinvalidinvalidu');
 if(!u||!ok)return r.status(401).json({error:'Wrong email or password'});
 const t=crypto.randomBytes(32).toString('hex');await pool.query('INSERT INTO sessions VALUES($1,$2,$3)',[sha(t),u.id,Date.now()+30*864e5]);
 r.set('Set-Cookie',`sid=${t}; HttpOnly; SameSite=Strict; Path=/; Max-Age=2592000${process.env.SECURE_COOKIES==='1'?'; Secure':''}`);r.json({ok:true})}));
app.post('/api/logout',auth,wrap(async(q,r)=>{await pool.query('DELETE FROM sessions WHERE token_hash=$1',[sha(cookie(q.headers.cookie).sid)]);r.set('Set-Cookie','sid=; Max-Age=0; Path=/');r.json({ok:true})}));
const meRow=id=>one('SELECT id uid,username,display,bio,avatar,banner,accent FROM users WHERE id=$1',[id]);
app.get('/api/me',auth,wrap(async(q,r)=>r.json(await meRow(q.user.id))));
const owned=async(url,uid)=>{if(url==null||url==='')return null;return(await one('SELECT url FROM files WHERE url=$1 AND owner=$2',[String(url),uid]))?.url}; // undefined = not yours
app.patch('/api/me',auth,wrap(async(q,r)=>{const b=q.body||{},u=await meRow(q.user.id),o={};
 o.display=b.display!==undefined?String(b.display).trim().slice(0,32)||u.username:u.display;o.bio=b.bio!==undefined?String(b.bio).slice(0,160):u.bio;o.accent=/^#[0-9a-f]{6}$/i.test(b.accent||'')?b.accent:u.accent;
 for(const k of['avatar','banner']){if(b[k]===undefined)o[k]=u[k];else{const v=await owned(b[k],q.user.id);if(v===undefined)return r.status(400).json({error:'Unknown file'});o[k]=v}}
 await pool.query('UPDATE users SET display=$1,bio=$2,accent=$3,avatar=$4,banner=$5 WHERE id=$6',[o.display,o.bio,o.accent,o.avatar,o.banner,q.user.id]);r.json(await meRow(q.user.id))}));
/* ---- uploads: the file type is decided by its contents, never by the name or client MIME; stored in Supabase Storage ---- */
function sniff(b){if(b.length<12)return null;const s=b.toString('latin1',0,12);
 if(b[0]===0x89&&s.slice(1,4)==='PNG')return['png','image'];if(b[0]===0xff&&b[1]===0xd8)return['jpg','image'];if(s.startsWith('GIF8'))return['gif','image'];
 if(s.startsWith('RIFF')&&s.slice(8,12)==='WEBP')return['webp','image'];if(s.startsWith('RIFF')&&s.slice(8,12)==='WAVE')return['wav','audio'];
 if(s.startsWith('OggS'))return['ogg','audio'];if(s.startsWith('ID3')||(b[0]===0xff&&(b[1]&0xe0)===0xe0))return['mp3','audio'];if(s.slice(4,8)==='ftyp')return['m4a','audio'];return null}
const MIME={png:'image/png',jpg:'image/jpeg',gif:'image/gif',webp:'image/webp',wav:'audio/wav',ogg:'audio/ogg',mp3:'audio/mpeg',m4a:'audio/mp4'};
async function store(name,buf,type){const h={apikey:SUPABASE_SERVICE_KEY,'Content-Type':type};if(SUPABASE_SERVICE_KEY.startsWith('eyJ'))h.Authorization='Bearer '+SUPABASE_SERVICE_KEY;
 const x=await fetch(`${SB}/storage/v1/object/${SUPABASE_BUCKET}/${name}`,{method:'POST',headers:h,body:buf});if(!x.ok)throw new Error('storage '+x.status+' '+(await x.text()).slice(0,200));
 return`${SB}/storage/v1/object/public/${SUPABASE_BUCKET}/${name}`}
/* ---- tracks vanish 10 hours after publishing; their files are deleted from storage so the free 1 GB never fills up ---- */
async function removeFiles(urls){if(!urls.length)return;const names=urls.map(u=>decodeURIComponent(u.split('/').pop()));
 const h={apikey:SUPABASE_SERVICE_KEY,'Content-Type':'application/json'};if(SUPABASE_SERVICE_KEY.startsWith('eyJ'))h.Authorization='Bearer '+SUPABASE_SERVICE_KEY;
 const x=await fetch(`${SB}/storage/v1/object/${SUPABASE_BUCKET}`,{method:'DELETE',headers:h,body:JSON.stringify({prefixes:names})});if(!x.ok)throw new Error('storage delete '+x.status);
 await pool.query('DELETE FROM files WHERE url=ANY($1)',[urls])}
async function sweep(){try{
 const dead=await all('SELECT id,audio,cover FROM tracks WHERE expires_at<=now() LIMIT 100');
 if(dead.length){await removeFiles(dead.flatMap(t=>[t.audio,t.cover]).filter(Boolean));await pool.query('DELETE FROM tracks WHERE id=ANY($1)',[dead.map(t=>t.id)])}
 const orph=await all("SELECT url FROM files f WHERE created_at<now()-interval '1 hour' AND NOT EXISTS(SELECT 1 FROM tracks t WHERE t.audio=f.url OR t.cover=f.url) AND NOT EXISTS(SELECT 1 FROM users u WHERE u.avatar=f.url OR u.banner=f.url) LIMIT 100");
 await removeFiles(orph.map(o=>o.url))}catch(e){console.error('sweep failed:',e.message)}}
app.post('/api/upload/:kind',auth,express.raw({type:'application/octet-stream',limit:'25mb'}),wrap(async(q,r)=>{
 const want={avatar:'image',banner:'image',cover:'image',audio:'audio'}[q.params.kind];if(!want)return r.status(400).json({error:'Unknown upload type'});
 if(limited('up'+q.user.id,30,3600e3))return r.status(429).json({error:'Upload limit reached, try again later'});
 const b=q.body;if(!Buffer.isBuffer(b)||!b.length)return r.status(400).json({error:'Empty file'});if(want==='image'&&b.length>8e6)return r.status(413).json({error:'Images must be under 8 MB'});
 const t=sniff(b);if(!t||t[1]!==want)return r.status(415).json({error:want==='image'?'Use a PNG, JPG, GIF or WebP image':'Use an MP3, WAV, OGG or M4A file'});
 const url=await store(crypto.randomBytes(12).toString('hex')+'.'+t[0],b,MIME[t[0]]);await pool.query('INSERT INTO files VALUES($1,$2,$3)',[url,q.user.id,q.params.kind]);r.json({url})}));
/* ---- music ---- */
function embed(u){let x;try{x=new URL(u)}catch{return null}if(x.protocol!=='https:')return null;
 if(/^(www\.|m\.)?soundcloud\.com$/.test(x.hostname)&&x.pathname.length>2)return'https://w.soundcloud.com/player/?visual=false&url='+encodeURIComponent(x.origin+x.pathname);
 if(x.hostname==='open.spotify.com'){const m=x.pathname.match(/^\/(?:intl-[a-z]+\/)?(track|album|playlist|episode)\/([A-Za-z0-9]+)$/);if(m)return`https://open.spotify.com/embed/${m[1]}/${m[2]}`}return null}
const TR=`SELECT t.id,t.title,t.artist,t.kind,t.audio,t.cover,t.embed,t.created_at,t.expires_at,${PUB} FROM tracks t JOIN users u ON u.id=t.owner`;
app.get('/api/tracks',auth,wrap(async(q,r)=>r.json(await all(TR+' WHERE t.expires_at>now() ORDER BY t.id DESC LIMIT 60'))));
app.post('/api/tracks',auth,wrap(async(q,r)=>{const b=q.body||{},title=String(b.title||'').trim().slice(0,80),artist=String(b.artist||'').trim().slice(0,60);
 if(!title||!artist)return r.status(400).json({error:'Add a title and artist name'});if(b.rights!==true)return r.status(400).json({error:'Confirm you have the rights to share this music'});
 const a=await owned(b.audio,q.user.id),c=await owned(b.cover,q.user.id);if(!a||c===undefined)return r.status(400).json({error:'Upload the audio file first'});
 const{id}=await one("INSERT INTO tracks(owner,title,artist,kind,audio,cover) VALUES($1,$2,$3,'file',$4,$5) RETURNING id",[q.user.id,title,artist,a,c]);r.json(await one(TR+' WHERE t.id=$1',[id]))}));
app.post('/api/links',auth,wrap(async(q,r)=>{const b=q.body||{},e=embed(b.url);if(!e)return r.status(400).json({error:'Paste a SoundCloud or Spotify link (track, album or playlist)'});
 const kind=e.includes('spotify')?'Spotify':'SoundCloud',title=String(b.title||'').trim().slice(0,80)||kind+' link',artist=String(b.artist||'').trim().slice(0,60)||kind;
 const{id}=await one("INSERT INTO tracks(owner,title,artist,kind,embed) VALUES($1,$2,$3,'link',$4) RETURNING id",[q.user.id,title,artist,e]);r.json(await one(TR+' WHERE t.id=$1',[id]))}));
app.delete('/api/tracks/:id',auth,wrap(async(q,r)=>{const t=await one('DELETE FROM tracks WHERE id=$1 AND owner=$2 RETURNING audio,cover',[num(q.params.id),q.user.id]);if(t)await removeFiles([t.audio,t.cover].filter(Boolean)).catch(()=>{});r.json({ok:!!t})}));
/* ---- servers ---- */
app.get('/api/servers',auth,wrap(async(q,r)=>{const s=await all('SELECT s.id,s.name,m.role FROM servers s JOIN members m ON m.server_id=s.id WHERE m.user_id=$1 ORDER BY s.id',[q.user.id]);
 for(const x of s){x.channels=await all('SELECT id,name,type FROM channels WHERE server_id=$1 ORDER BY type DESC,id',[x.id]);x.members=await all(`SELECT ${PUB},m.role FROM members m JOIN users u ON u.id=m.user_id WHERE m.server_id=$1`,[x.id])}r.json(s)}));
app.post('/api/servers',auth,wrap(async(q,r)=>{const name=String(q.body?.name||'').trim().slice(0,50);if(!name)return r.status(400).json({error:'Name your server'});if(limited('srv'+q.user.id,5,3600e3))return r.status(429).json({error:'Slow down'});
 const{id}=await one('INSERT INTO servers(name,owner_id) VALUES($1,$2) RETURNING id',[name,q.user.id]);await pool.query("INSERT INTO members VALUES($1,$2,'owner')",[id,q.user.id]);
 await pool.query("INSERT INTO channels(server_id,name,type) VALUES($1,'general','text'),($1,'Lounge','voice')",[id]);r.json({id})}));
app.post('/api/servers/:id/channels',auth,wrap(async(q,r)=>{if(!canManage(await role(q.params.id,q.user.id)))return r.status(403).json({error:'Only owners and admins can do that'});
 const type=q.body?.type==='voice'?'voice':'text',n=String(q.body?.name||'').trim().slice(0,40);if(!n)return r.status(400).json({error:'Name required'});
 try{r.json(await one('INSERT INTO channels(server_id,name,type) VALUES($1,$2,$3) RETURNING id',[num(q.params.id),type==='text'?n.toLowerCase().replace(/[^a-z0-9]+/g,'-'):n,type]))}catch(e){if(e.code==='23505')return r.status(409).json({error:'That channel exists'});throw e}}));
app.post('/api/servers/:id/invites',auth,wrap(async(q,r)=>{if(!canManage(await role(q.params.id,q.user.id)))return r.status(403).json({error:'Only owners and admins can do that'});
 const c=crypto.randomBytes(6).toString('base64url');await pool.query('INSERT INTO invites(code,server_id,expires_at,max_uses) VALUES($1,$2,$3,50)',[c,num(q.params.id),Date.now()+7*864e5]);r.json({code:c})}));
app.post('/api/invites/:code/join',auth,wrap(async(q,r)=>{const i=await one('SELECT * FROM invites WHERE code=$1',[q.params.code]);
 if(!i||(i.expires_at&&+i.expires_at<Date.now())||(i.max_uses&&i.uses>=i.max_uses))return r.status(404).json({error:'That invite is invalid or expired'});
 await pool.query("INSERT INTO members VALUES($1,$2,'member') ON CONFLICT DO NOTHING",[i.server_id,q.user.id]);await pool.query('UPDATE invites SET uses=uses+1 WHERE code=$1',[i.code]);r.json({id:i.server_id})}));
const MS=`SELECT m.id,m.channel_id,m.content,m.created_at,${PUB} FROM messages m JOIN users u ON u.id=m.author_id`;
app.get('/api/channels/:id/messages',auth,wrap(async(q,r)=>{const c=await chan(q.params.id);if(!c||c.type!=='text'||!await role(c.server_id,q.user.id))return r.status(404).json({error:'Not found'});
 r.json((await all(MS+' WHERE m.channel_id=$1 ORDER BY m.id DESC LIMIT 60',[c.id])).reverse())}));
app.post('/api/channels/:id/messages',auth,wrap(async(q,r)=>{const c=await chan(q.params.id);if(!c||c.type!=='text'||!await role(c.server_id,q.user.id))return r.status(404).json({error:'Not found'});
 if(limited('msg'+q.user.id,10,10e3))return r.status(429).json({error:'Slow down'});const t=String(q.body?.content||'').trim();if(!t||t.length>2000)return r.status(400).json({error:'Messages are 1-2000 characters'});
 const{id}=await one('INSERT INTO messages(channel_id,author_id,content) VALUES($1,$2,$3) RETURNING id',[c.id,q.user.id,t]),m=await one(MS+' WHERE m.id=$1',[id]);bcast(c.server_id,{type:'message',message:m});r.json(m)}));
app.delete('/api/messages/:id',auth,wrap(async(q,r)=>{const m=await one('SELECT * FROM messages WHERE id=$1',[num(q.params.id)]);if(!m)return r.status(404).json({error:'Not found'});const c=await chan(m.channel_id);
 if(m.author_id!==q.user.id&&!canMod(await role(c.server_id,q.user.id)))return r.status(403).json({error:'Not allowed'});await pool.query('DELETE FROM messages WHERE id=$1',[m.id]);bcast(c.server_id,{type:'delete',id:m.id});r.json({ok:true})}));
app.use(express.static(path.join(__dirname,'public')));
/* ---- realtime: chat + voice/video signalling (peer-to-peer mesh, up to 6 people per room) ---- */
const wss=new WebSocketServer({noServer:true,maxPayload:20000}),socks=new Set(),rooms=new Map();
server.on('upgrade',async(q,s,h)=>{try{const u=await userFrom(q);if(!u||(q.headers.origin&&new URL(q.headers.origin).host!==q.headers.host)){s.destroy();return}
 wss.handleUpgrade(q,s,h,ws=>{ws.uid=u.id;ws.id=crypto.randomBytes(6).toString('hex');socks.add(ws);ws.on('error',()=>{});
  ws.on('message',async raw=>{try{const m=JSON.parse(raw);
   if(m.type==='vjoin'){const c=await chan(m.channel);if(!c||c.type!=='voice'||!await role(c.server_id,ws.uid))return;leave(ws);const room=rooms.get(c.id)||new Set();if(room.size>=6)return ws.send(JSON.stringify({type:'vfull'}));
    rooms.set(c.id,room);ws.send(JSON.stringify({type:'vpeers',peers:[...room].map(p=>({id:p.id,uid:p.uid}))}));room.forEach(p=>p.send(JSON.stringify({type:'vnew',id:ws.id,uid:ws.uid})));room.add(ws);ws.room=c.id}
   else if(m.type==='vleave')leave(ws);
   else if(m.type==='sig'&&ws.room){const t=[...rooms.get(ws.room)].find(p=>p.id===m.to);t&&t.send(JSON.stringify({type:'sig',from:ws.id,data:m.data}))}}catch{}});
  ws.on('close',()=>{leave(ws);socks.delete(ws)})})}catch{s.destroy()}});
function leave(ws){if(!ws.room)return;const room=rooms.get(ws.room);if(room){room.delete(ws);room.forEach(p=>p.send(JSON.stringify({type:'vleft',id:ws.id})))}ws.room=null}
async function bcast(sid,p){try{const ids=new Set((await all('SELECT user_id FROM members WHERE server_id=$1',[sid])).map(x=>x.user_id)),s=JSON.stringify(p);for(const ws of socks)if(ws.readyState===1&&ids.has(ws.uid))ws.send(s)}catch{}}
